import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import TelaConfiguracaoCadastroUsuario from './TelaConfiguracaoCadastroUsuario'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TelaConfiguracaoCadastroUsuario />
  </React.StrictMode>,
)
