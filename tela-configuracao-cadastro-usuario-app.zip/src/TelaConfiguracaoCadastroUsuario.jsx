import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";

export default function TelaConfiguracaoCadastroUsuario() {
  const [showPassword, setShowPassword] = useState({
    senha: false,
    confirmar: false,
  });

  return (
    <div className="flex h-screen bg-white font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-blue-700 text-white flex flex-col justify-between">
        <div>
          <div className="p-4 font-semibold text-base">Menu Principal</div>
          <nav className="flex flex-col space-y-1 px-2">
            <a href="#" className="hover:bg-blue-600 rounded p-2">Dashboard</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Ações</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Gestão de Tarefas</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Cadastro</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Financeiro</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Eleição 2024</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Configurações</a>
          </nav>
        </div>
        <div className="p-4">
          <a href="#" className="hover:bg-blue-600 rounded p-2 block">Sair</a>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-blue-600 text-white p-4">
          <h1 className="text-lg font-semibold">Configurações</h1>
          <p className="text-sm font-normal">Gerencie suas configurações de usuário</p>
        </header>

        {/* Tabs */}
        <div className="p-6">
          <div className="border-b flex space-x-6 mb-6 text-sm font-medium">
            <button className="pb-2 text-gray-600 hover:text-black">
              Alteração de senha
            </button>
            <button className="pb-2 border-b-2 border-blue-600 text-blue-600">
              Cadastro de Usuário
            </button>
            <button className="pb-2 text-gray-600 hover:text-black">
              Administração de Usuários
            </button>
          </div>

          {/* Form */}
          <div className="max-w-2xl">
            <h2 className="text-xl font-bold mb-6">Alteração de senha</h2>

            {/* Nome e Sobrenome */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">Nome</label>
                <input type="text" className="w-full border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-600" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Sobrenome</label>
                <input type="text" className="w-full border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-600" />
              </div>
            </div>

            {/* E-mail */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">E-mail</label>
              <input type="email" className="w-full border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-600" />
            </div>

            {/* Tipo de Perfil */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Tipo de perfil</label>
              <select className="w-full border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-600">
                <option>Usuário comum</option>
                <option>Administrador</option>
              </select>
            </div>

            {/* Senha */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Senha</label>
              <div className="relative">
                <input
                  type={showPassword.senha ? "text" : "password"}
                  className="w-full border rounded p-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <button
                  type="button"
                  className="absolute right-2 top-2 text-gray-600"
                  onClick={() => setShowPassword((prev) => ({ ...prev, senha: !prev.senha }))}
                >
                  {showPassword.senha ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Confirmar Senha */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-1">Confirmar senha</label>
              <div className="relative">
                <input
                  type={showPassword.confirmar ? "text" : "password"}
                  className="w-full border rounded p-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <button
                  type="button"
                  className="absolute right-2 top-2 text-gray-600"
                  onClick={() => setShowPassword((prev) => ({ ...prev, confirmar: !prev.confirmar }))}
                >
                  {showPassword.confirmar ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none"
                viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Alterar senha
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}