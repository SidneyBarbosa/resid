import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

// Dados mockados
const chartData = [
  { name: "FAROLÂNDIA", votos: 270 },
  { name: "GRAGERU", votos: 230 },
  { name: "SÃO CONRADO", votos: 150 },
  { name: "JABOTIANA", votos: 120 },
  { name: "JARDINS", votos: 100 },
  { name: "SALGADO FILHO", votos: 80 },
  { name: "LUIZA", votos: 60 },
  { name: "SUÍSSA", votos: 40 },
];

const tableData = [
  { bairro: "Eduardo Gomes", percentual: 2, absolutos: "20%" },
  { bairro: "Atalaia", percentual: 2, absolutos: "20%" },
  { bairro: "Centro", percentual: 1, absolutos: "10%" },
  { bairro: "Jabotiana", percentual: 1, absolutos: "10%" },
  { bairro: "Ponto Novo", percentual: 1, absolutos: "10%" },
  { bairro: "Inácio Barbosa", percentual: 1, absolutos: "10%" },
  { bairro: "Conjunto João Alves", percentual: 1, absolutos: "10%" },
  { bairro: "Farolândia", percentual: 1, absolutos: "10%" },
];

export default function Eleicao2024() {
  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-blue-800 text-white flex flex-col justify-between">
        <nav className="p-4">
          <ul className="space-y-2 text-sm font-medium">
            <li className="hover:bg-blue-700 p-2 rounded cursor-pointer">Dashboard</li>
            <li className="hover:bg-blue-700 p-2 rounded cursor-pointer">Apos</li>
            <li className="hover:bg-blue-700 p-2 rounded cursor-pointer">Gestão de Tarefas</li>
            <li className="hover:bg-blue-700 p-2 rounded cursor-pointer">Cadastro</li>
            <li className="hover:bg-blue-700 p-2 rounded cursor-pointer">Financeiro</li>
            <li className="bg-blue-600 p-2 rounded cursor-pointer">Eleição 2024</li>
            <li className="hover:bg-blue-700 p-2 rounded cursor-pointer">Configurações</li>
          </ul>
        </nav>
        <div className="p-4 text-xs cursor-pointer hover:underline">Sair</div>
      </aside>

      {/* Conteúdo principal */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-blue-700 text-white p-4">
          <h1 className="text-2xl font-bold">Eleição 2024</h1>
          <p className="text-sm">Resultado Eleitoral 2024 - Vereador XXX</p>
        </header>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Cards resumo */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white shadow rounded-lg p-6 text-center">
              <p className="text-gray-600 text-sm">Total de Votos Absolutos</p>
              <h2 className="text-4xl font-extrabold text-blue-700">3.847</h2>
            </div>
            <div className="bg-white shadow rounded-lg p-6 text-center">
              <p className="text-gray-600 text-sm">Média Percentual por Bairro</p>
              <h2 className="text-4xl font-extrabold text-blue-700">1.27%</h2>
            </div>
          </div>

          {/* Gráfico */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="font-semibold mb-4 text-sm">10 Bairros com Mais Votos em 2024</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} interval={0} angle={0} textAnchor="middle" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="votos" fill="#2563EB" barSize={40} radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Tabela */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="font-semibold mb-4 text-sm">Resultados por Bairro</h3>
            <input
              type="text"
              placeholder="Buscar bairro..."
              className="w-full border rounded-lg p-2 mb-4 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            />
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-gray-100 text-left text-gray-600">
                  <th className="p-2 font-medium">BAIRRO</th>
                  <th className="p-2 font-medium">PERCENTUAL (%)</th>
                  <th className="p-2 font-medium">VOTOS ABSOLUTOS</th>
                </tr>
              </thead>
              <tbody>
                {tableData.map((row, index) => (
                  <tr key={index} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                    <td className="p-2">{row.bairro}</td>
                    <td className="p-2">{row.percentual}</td>
                    <td className="p-2">{row.absolutos}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}