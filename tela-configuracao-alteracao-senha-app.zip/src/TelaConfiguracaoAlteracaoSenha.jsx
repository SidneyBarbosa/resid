import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { Button } from "./components/Button";

export default function TelaConfiguracaoAlteracaoSenha() {
  const [showPassword, setShowPassword] = useState({
    atual: false,
    nova: false,
    confirmar: false,
  });

  return (
    <div className="flex h-screen bg-white font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-blue-700 text-white flex flex-col justify-between">
        <div>
          <div className="p-4 font-semibold text-base">Menu Principal</div>
          <nav className="flex flex-col space-y-1 px-2">
            <a href="#" className="hover:bg-blue-600 rounded p-2">Dashboard</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Ações</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Gestão de Tarefas</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Cadastro</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Financeiro</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Eleição 2024</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Configurações</a>
          </nav>
        </div>
        <div className="p-4">
          <a href="#" className="hover:bg-blue-600 rounded p-2 block">Sair</a>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-blue-600 text-white p-4">
          <h1 className="text-lg font-semibold">Configurações</h1>
          <p className="text-sm font-normal">Gerencie suas configurações de usuário</p>
        </header>

        {/* Tabs */}
        <div className="p-6">
          <div className="border-b flex space-x-6 mb-6 text-sm font-medium">
            <button className="pb-2 border-b-2 border-blue-600 text-blue-600">
              Alteração de senha
            </button>
            <button className="pb-2 text-gray-600 hover:text-black">
              Cadastro de Usuário
            </button>
            <button className="pb-2 text-gray-600 hover:text-black">
              Administração de Usuários
            </button>
          </div>

          {/* Form */}
          <div className="max-w-2xl">
            <h2 className="text-xl font-bold mb-6">Alteração de senha</h2>

            {/* Senha Atual */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Senha atual</label>
              <div className="relative">
                <input
                  type={showPassword.atual ? "text" : "password"}
                  className="w-full border rounded p-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <button
                  type="button"
                  className="absolute right-2 top-2 text-gray-600"
                  onClick={() =>
                    setShowPassword((prev) => ({ ...prev, atual: !prev.atual }))
                  }
                >
                  {showPassword.atual ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Nova Senha */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">
                Nova senha (exatamente 8 caracteres)
              </label>
              <div className="relative">
                <input
                  type={showPassword.nova ? "text" : "password"}
                  className="w-full border rounded p-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <button
                  type="button"
                  className="absolute right-2 top-2 text-gray-600"
                  onClick={() =>
                    setShowPassword((prev) => ({ ...prev, nova: !prev.nova }))
                  }
                >
                  {showPassword.nova ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {/* Confirmar Senha */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-1">
                Confirmar nova senha
              </label>
              <div className="relative">
                <input
                  type={showPassword.confirmar ? "text" : "password"}
                  className="w-full border rounded p-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <button
                  type="button"
                  className="absolute right-2 top-2 text-gray-600"
                  onClick={() =>
                    setShowPassword((prev) => ({ ...prev, confirmar: !prev.confirmar }))
                  }
                >
                  {showPassword.confirmar ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <Button className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto">
              Alterar senha
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}