import { useState } from "react";
import { RotateCw } from "lucide-react";

export default function TelaConfiguracaoAdministracaoUsuarios() {
  const [usuarios] = useState([
    {
      nome: "Administrador Sistema",
      email: "administrador@sistema.local",
      perfil: "Administrador",
      dataCriacao: "11/05/2025",
      ultimoAcesso: "24/06/2025 18:33",
      pagina: "Login",
    },
  ]);

  return (
    <div className="flex h-screen bg-white font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-blue-700 text-white flex flex-col justify-between">
        <div>
          <div className="p-4 font-semibold text-base">Menu Principal</div>
          <nav className="flex flex-col space-y-1 px-2">
            <a href="#" className="hover:bg-blue-600 rounded p-2">Dashboard</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Ações</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Gestão de Tarefas</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Cadastro</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Financeiro</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Eleição 2024</a>
            <a href="#" className="hover:bg-blue-600 rounded p-2">Configurações</a>
          </nav>
        </div>
        <div className="p-4">
          <a href="#" className="hover:bg-blue-600 rounded p-2 block">Sair</a>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-blue-600 text-white p-4">
          <h1 className="text-lg font-semibold">Configurações</h1>
          <p className="text-sm font-normal">Gerencie suas configurações de usuário</p>
        </header>

        {/* Tabs */}
        <div className="p-6">
          <div className="border-b flex space-x-6 mb-6 text-sm font-medium">
            <button className="pb-2 text-gray-600 hover:text-black">
              Alteração de senha
            </button>
            <button className="pb-2 text-gray-600 hover:text-black">
              Cadastro de Usuário
            </button>
            <button className="pb-2 border-b-2 border-blue-600 text-blue-600">
              Administração de Usuários
            </button>
          </div>

          {/* Título e Botão */}
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-xl font-bold">Administração de Usuários</h2>
              <p className="text-sm text-gray-600">
                Gerencie usuários e suas permissões de acesso às páginas do sistema
              </p>
              <p className="text-xs text-gray-500 mt-1">1 usuário encontrado</p>
            </div>
            <button className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-sm border px-3 py-2 rounded">
              <RotateCw size={16} />
              Atualizar Lista
            </button>
          </div>

          {/* Tabela */}
          <div className="overflow-x-auto border rounded-lg shadow-sm">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 text-left text-gray-700">
                <tr>
                  <th className="px-4 py-2 font-medium">Nome</th>
                  <th className="px-4 py-2 font-medium">E-mail</th>
                  <th className="px-4 py-2 font-medium">Perfil</th>
                  <th className="px-4 py-2 font-medium">Data de criação</th>
                  <th className="px-4 py-2 font-medium">Último acesso</th>
                  <th className="px-4 py-2 font-medium">Ações</th>
                </tr>
              </thead>
              <tbody>
                {usuarios.map((u, i) => (
                  <tr key={i} className="border-t hover:bg-gray-50">
                    <td className="px-4 py-3">{u.nome}</td>
                    <td className="px-4 py-3">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-medium">
                        {u.perfil}
                      </span>
                    </td>
                    <td className="px-4 py-3">{u.dataCriacao}</td>
                    <td className="px-4 py-3">
                      {u.ultimoAcesso} <br />
                      <span className="text-xs text-gray-500">Página: {u.pagina}</span>
                    </td>
                    <td className="px-4 py-3 flex gap-2">
                      <button className="bg-gray-200 hover:bg-gray-300 text-xs px-3 py-1 rounded">
                        Editar Permissões
                      </button>
                      <button className="bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1 rounded">
                        Remover
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}