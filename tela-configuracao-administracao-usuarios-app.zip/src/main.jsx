import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import TelaConfiguracaoAdministracaoUsuarios from './components/TelaConfiguracaoAdministracaoUsuarios'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TelaConfiguracaoAdministracaoUsuarios />
  </React.StrictMode>,
)